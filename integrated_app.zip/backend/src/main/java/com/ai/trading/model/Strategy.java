package com.ai.trading.model;

public class Strategy {
    private String name;
    // getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}